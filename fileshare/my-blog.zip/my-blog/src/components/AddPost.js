import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddPost = ({ addPost }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title && content) {
      addPost(title, content);
      navigate('/');
    } else {
      alert('Please fill both fields!');
    }
  };

  return (
    <div className="card">
      <h2>Add New Post</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
        <input 
          type="text" 
          placeholder="Post Title" 
          value={title}
          onChange={e => setTitle(e.target.value)}
          style={{ marginBottom: '10px', padding: '10px' }}
        />
        <textarea 
          placeholder="Post Content"
          value={content}
          onChange={e => setContent(e.target.value)}
          rows="6"
          style={{ marginBottom: '10px', padding: '10px' }}
        />
        <button type="submit" style={{ backgroundColor: '#007bff', color: 'white' }}>Add Post</button>
      </form>
    </div>
  );
};

export default AddPost;
