import React from 'react';
import { Link } from 'react-router-dom';

const BlogList = ({ posts, deletePost }) => {
  return (
    <div>
      <h2>All Blog Posts</h2>
      {posts.map(post => (
        <div key={post.id} className="card">
          <h3>{post.title}</h3>
          <Link to={`/post/${post.id}`}>
            <button className="read">Read More</button>
          </Link>
          <button onClick={() => deletePost(post.id)} className="delete">
            Delete
          </button>
        </div>
      ))}
    </div>
  );
};

export default BlogList;
