import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const BlogPost = ({ posts }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const post = posts.find(p => p.id === parseInt(id));

  if (!post) {
    return <h2>Post Not Found</h2>;
  }

  return (
    <div className="card">
      <h2>{post.title}</h2>
      <p>{post.content}</p>
      <button onClick={() => navigate(-1)}>Go Back</button>
    </div>
  );
};

export default BlogPost;
