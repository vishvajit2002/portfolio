import React, { useState } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import BlogList from './components/BlogList';
import BlogPost from './components/BlogPost';
import AddPost from './components/AddPost';

const App = () => {
  const [posts, setPosts] = useState([
    { id: 1, title: 'Welcome to My Blog', content: 'Welcome to my personal blogging website where I share my learnings, ideas, projects and experiences.' },
    { id: 2, title: 'React is Awesome', content: 'React helps build scalable and interactive UIs easily. With components, states, and props, React simplifies modern web development.' },
    { id: 3, title: 'TCS Life', content: 'Working at TCS gives great exposure to different clients, projects and technologies. However, balancing work and learning is key!' },
    { id: 4, title: 'Corporate Work Tips', content: 'Always document your work, communicate clearly, focus on deadlines and never stop learning new things on the job.' },
    { id: 5, title: 'Frontend vs Backend', content: 'Frontend handles UI/UX, backend handles logic & database. Full stack means handling both sides.' },
    { id: 6, title: '10 VS Code Tips', content: 'Shortcuts, extensions, IntelliSense, themes, Emmet abbreviations, live-server, prettier, snippets, terminal integration & Git integration.' }
  ]);

  const addPost = (title, content) => {
    const newPost = { id: posts.length + 1, title, content };
    setPosts([newPost, ...posts]);
  };

  const deletePost = (id) => {
    setPosts(posts.filter(post => post.id !== id));
  };

  return (
    <div className="container">
      <h1 style={{ textAlign: 'center' }}>📝 My Tech Blog</h1>

      <nav>
        <Link to="/">Home</Link>
        <Link to="/add">Add Post</Link>
      </nav>

      <Routes>
        <Route path="/" element={<BlogList posts={posts} deletePost={deletePost} />} />
        <Route path="/post/:id" element={<BlogPost posts={posts} />} />
        <Route path="/add" element={<AddPost addPost={addPost} />} />
      </Routes>
    </div>
  );
};

export default App;
